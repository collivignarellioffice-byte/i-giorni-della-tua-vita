begin;
create table if not exists public.life_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  birth_date date not null check (birth_date >= date '1900-01-01' and birth_date <= current_date)
);
create table if not exists public.life_notes (
  user_id uuid not null references public.life_profiles(user_id) on delete cascade,
  note_key text not null check (note_key ~ '^(day|week|month):-?[0-9]{1,6}$'),
  body text not null check (char_length(body) between 1 and 8000),
  primary key (user_id, note_key)
);
alter table public.life_profiles enable row level security;
alter table public.life_notes enable row level security;
revoke all on public.life_profiles, public.life_notes from anon, authenticated;
grant select, insert on public.life_profiles to authenticated;
grant select, insert, update, delete on public.life_notes to authenticated;
drop policy if exists own_profile on public.life_profiles;
create policy own_profile on public.life_profiles to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
drop policy if exists own_notes on public.life_notes;
create policy own_notes on public.life_notes to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create table if not exists public.life_gmail_connections (
  user_id uuid primary key references public.life_profiles(user_id) on delete cascade,
  address text not null,
  encrypted_token text not null
);
create table if not exists public.life_gmail_oauth (
  state uuid primary key,
  user_id uuid not null references public.life_profiles(user_id) on delete cascade,
  address text not null,
  verifier text not null,
  expires_at timestamptz not null
);
create table if not exists public.life_email_jobs (
  id uuid primary key,
  user_id uuid not null references public.life_profiles(user_id) on delete cascade,
  recipient text not null,
  subject text not null,
  body text not null,
  local_time text not null,
  due_at timestamptz not null,
  status text not null default 'scheduled' check (status in ('scheduled','sending','sent','cancelled','check','reconnect'))
);
create index if not exists life_email_jobs_due on public.life_email_jobs (due_at) where status = 'scheduled';

alter table public.life_gmail_connections enable row level security;
alter table public.life_gmail_oauth enable row level security;
alter table public.life_email_jobs enable row level security;
revoke all on public.life_gmail_connections, public.life_gmail_oauth, public.life_email_jobs from anon, authenticated;
grant select, insert, update, delete on public.life_gmail_connections, public.life_gmail_oauth, public.life_email_jobs to service_role;

create or replace function public.life_claim_emails()
returns setof public.life_email_jobs
language sql set search_path = '' as $$
  update public.life_email_jobs j set status = 'sending'
  where j.id in (
    select q.id from public.life_email_jobs q
    where q.status = 'scheduled' and q.due_at <= now()
    order by q.due_at limit 10 for update skip locked
  )
  returning j.*;
$$;
revoke all on function public.life_claim_emails() from public, anon, authenticated;
grant execute on function public.life_claim_emails() to service_role;
commit;

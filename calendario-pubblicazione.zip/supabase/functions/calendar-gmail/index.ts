import { createClient } from 'npm:@supabase/supabase-js@2.50.0';

const env = (name: string) => Deno.env.get(name) || '';
const root = env('SUPABASE_URL');
const app = new URL(env('CALENDAR_APP_URL'));
const callback = root + '/functions/v1/calendar-gmail/callback';
const scope = 'https://www.googleapis.com/auth/gmail.send';
const db = createClient(root, env('SUPABASE_SERVICE_ROLE_KEY'), {auth:{persistSession:false}});
const auth = createClient(root, env('SUPABASE_ANON_KEY'), {auth:{persistSession:false}});
const utf8 = new TextEncoder();
const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const address = /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/;
const cors = {
  'Access-Control-Allow-Origin':app.origin,
  'Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods':'POST, OPTIONS',
  'Cache-Control':'no-store',
  Vary:'Origin'
};
const json = (value: unknown, status = 200) => Response.json(value, {status,headers:cors});
const data = <T>(result: {data:T; error:unknown}): T => {
  if (result.error) throw new Error('Operazione temporaneamente non disponibile.');
  return result.data;
};
function b64(bytes: Uint8Array): string {
  return btoa(Array.from(bytes, byte => String.fromCharCode(byte)).join(''));
}
const b64url = (bytes: Uint8Array) => b64(bytes).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
const decode = (value: string) => Uint8Array.from(atob(value), letter => letter.charCodeAt(0));

async function cipher() {
  const key = decode(env('CALENDAR_TOKEN_KEY'));
  if (key.length !== 32) throw Error('Configurazione chiave Gmail non valida.');
  return await crypto.subtle.importKey('raw', key, 'AES-GCM', false, ['encrypt','decrypt']);
}
async function encrypt(token: string, user: string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const value = await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:utf8.encode(user)}, await cipher(), utf8.encode(token));
  return b64(iv) + '.' + b64(new Uint8Array(value));
}
async function decrypt(token: string, user: string) {
  const [iv, value] = token.split('.');
  const bytes = await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(iv),additionalData:utf8.encode(user)}, await cipher(), decode(value));
  return new TextDecoder().decode(bytes);
}

async function tokenRequest(fields: Record<string,string>) {
  return await fetch('https://oauth2.googleapis.com/token', {
    method:'POST',
    body:new URLSearchParams({
      client_id:env('CALENDAR_GOOGLE_ID'),client_secret:env('CALENDAR_GOOGLE_SECRET'),...fields
    })
  });
}

async function consent(user: string, email: string) {
  if (!env('CALENDAR_GOOGLE_ID') || !env('CALENDAR_GOOGLE_SECRET')) throw Error('La funzione Gmail non è ancora attiva.');
  const state = crypto.randomUUID();
  const verifier = b64url(crypto.getRandomValues(new Uint8Array(32)));
  const challenge = b64url(new Uint8Array(await crypto.subtle.digest('SHA-256', utf8.encode(verifier))));
  data(await db.from('life_gmail_oauth').delete().lt('expires_at',new Date().toISOString()));
  data(await db.from('life_gmail_oauth').insert({
    state, user_id:user,address:email,verifier,expires_at:new Date(Date.now()+600000).toISOString()
  }));
  const google = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  google.search = new URLSearchParams({
    client_id:env('CALENDAR_GOOGLE_ID'),redirect_uri:callback,response_type:'code',
    scope:'openid email '+scope,access_type:'offline',prompt:'consent',login_hint:email,
    state,code_challenge:challenge,code_challenge_method:'S256'
  }).toString();
  return {url:google.href};
}

async function finishConsent(url: URL) {
  const back = new URL(app);
  back.searchParams.set('gmail','errore');
  const state = url.searchParams.get('state') || '';
  const code = url.searchParams.get('code');
  if (!uuid.test(state) || !code) return Response.redirect(back,303);
  try {
    const claim = data(await db.from('life_gmail_oauth').delete().eq('state',state)
      .gt('expires_at',new Date().toISOString()).select().maybeSingle());
    if (!claim) return Response.redirect(back,303);
    const exchange = await tokenRequest({grant_type:'authorization_code',code,redirect_uri:callback,code_verifier:claim.verifier});
    if (!exchange.ok) return Response.redirect(back,303);
    const token = await exchange.json();
    if (!token.refresh_token || !token.scope?.split(' ').includes(scope)) return Response.redirect(back,303);
    const details = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
      headers:{Authorization:'Bearer '+token.access_token}
    });
    if (!details.ok) return Response.redirect(back,303);
    const profile = await details.json();
    if (!profile.email_verified || profile.email.toLowerCase() !== claim.address.toLowerCase()) {
      back.searchParams.set('gmail','account');
      return Response.redirect(back,303);
    }
    data(await db.from('life_gmail_connections').upsert({
      user_id:claim.user_id,address:profile.email,
      encrypted_token:await encrypt(token.refresh_token,claim.user_id)
    }));
    back.searchParams.set('gmail','collegato');
  } catch {
    // Report failure in the app without exposing OAuth tokens or provider payloads.
  }
  return Response.redirect(back,303);
}

function romeTimestamp(date: string, time: string) {
  if (!/^\d{4}-\d\d-\d\d$/.test(date) || !/^\d\d:\d\d$/.test(time)) throw Error('Data o ora non valida.');
  const local = date + 'T' + time;
  const formatted = new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Rome',dateStyle:'short',timeStyle:'short'});
  for (const hour of ['02','01']) {
    const candidate = new Date(local + ':00+' + hour + ':00');
    if (Number.isFinite(+candidate) && formatted.format(candidate).replace(' ','T') === local) return candidate;
  }
  throw Error('L’orario selezionato non esiste nel fuso italiano.');
}

async function schedule(user: string, input: Record<string,string>) {
  const {id,to,subject,body,date,time} = input;
  if (![id,to,subject,body,date,time].every(value => typeof value === 'string') ||
      !uuid.test(id) || to.length > 254 || !/^[\x21-\x7e]+$/.test(to) || !address.test(to) ||
      !subject.trim() || subject.length > 150 || /[\r\n]/.test(subject) || !body.trim() || body.length > 4000) {
    throw Error('Verifica destinatario, oggetto e messaggio.');
  }
  const connected = data(await db.from('life_gmail_connections').select('address').eq('user_id',user).maybeSingle());
  if (!connected) throw Error('Collega Gmail nelle impostazioni.');
  const due = romeTimestamp(date,time);
  if (+due <= Date.now()) throw Error('Scegli un orario futuro.');
  const {count,error} = await db.from('life_email_jobs').select('id',{head:true,count:'exact'}).eq('user_id',user).eq('status','scheduled');
  if (error || count === null) throw Error('Impossibile controllare le email in attesa.');
  if (count >= 100) throw Error('Hai raggiunto il limite di 100 invii in attesa.');
  data(await db.from('life_email_jobs').upsert({
    id,user_id:user,recipient:to,subject,body,local_time:date+' '+time,due_at:due.toISOString()
  },{onConflict:'id',ignoreDuplicates:true}));
  return {ok:true};
}

async function delivery(job: {id:string;user_id:string;recipient:string;subject:string;body:string}) {
  const connection = data(await db.from('life_gmail_connections').select('address,encrypted_token').eq('user_id',job.user_id).maybeSingle());
  if (!connection) return 'reconnect';
  const refresh = await tokenRequest({
    grant_type:'refresh_token',refresh_token:await decrypt(connection.encrypted_token,job.user_id)
  });
  if (!refresh.ok) return refresh.status === 400 ? 'reconnect' : 'check';
  const token = await refresh.json();
  const subject = Array.from(job.subject.matchAll(/.{1,12}/gu), part => '=?UTF-8?B?'+b64(utf8.encode(part[0]))+'?=').join('\r\n ');
  const body = b64(utf8.encode(job.body)).match(/.{1,76}/g)?.join('\r\n') || '';
  const message = [
    'From: '+connection.address,'To: '+job.recipient,'Subject: '+subject,'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8','Content-Transfer-Encoding: base64','',body
  ].join('\r\n');
  const result = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send',{
    method:'POST',headers:{Authorization:'Bearer '+token.access_token,'Content-Type':'application/json'},
    body:JSON.stringify({raw:b64url(utf8.encode(message))})
  });
  return result.ok ? 'sent' : result.status === 401 || result.status === 403 ? 'reconnect' : 'check';
}

Deno.serve(async req => {
  const url = new URL(req.url);
  if (req.method === 'GET' && url.pathname.endsWith('/callback')) return await finishConsent(url);
  if (req.method === 'OPTIONS') return new Response(null,{headers:cors});
  if (req.method !== 'POST') return json({error:'Metodo non disponibile.'},405);
  const token = req.headers.get('Authorization')?.replace(/^Bearer /i,'');
  if (url.pathname.endsWith('/deliver')) {
    if (!env('CALENDAR_CRON_SECRET') || token !== env('CALENDAR_CRON_SECRET')) return json({},401);
    try {
      for (const job of data(await db.rpc('life_claim_emails'))) {
        let status = 'check';
        try { status = await delivery(job); } catch { /* Verify before retrying an uncertain send. */ }
        data(await db.from('life_email_jobs').update({status}).eq('id',job.id).eq('status','sending'));
      }
      return json({ok:true});
    } catch { return json({error:'Coda non disponibile.'},500); }
  }
  if (req.headers.get('Origin') !== app.origin || !token) return json({error:'Accedi per continuare.'},401);
  const account = await auth.auth.getUser(token);
  const user = account.data?.user;
  if (account.error || !user?.email || !user.email_confirmed_at) return json({error:'Accesso scaduto.'},401);
  try {
    const input = await req.json();
    if (input.action === 'connect') return json(await consent(user.id,user.email));
    if (input.action === 'status') {
      const record = data(await db.from('life_gmail_connections').select('address').eq('user_id',user.id).maybeSingle());
      return json({address:record?.address || ''});
    }
    if (input.action === 'schedule') return json(await schedule(user.id,input));
    if (input.action === 'list') return json(data(await db.from('life_email_jobs').select('id,recipient,subject,local_time,status')
      .eq('user_id',user.id).order('due_at',{ascending:false}).limit(100)));
    if (input.action === 'cancel' && uuid.test(input.id)) {
      const job = data(await db.from('life_email_jobs').update({status:'cancelled'})
        .eq('user_id',user.id).eq('id',input.id).eq('status','scheduled').select('id').maybeSingle());
      if (!job) return json({error:'L’email non è più in attesa.'},409);
      return json({ok:true});
    }
    return json({error:'Operazione non riconosciuta.'},400);
  } catch (failure) {
    return json({error: failure instanceof Error ? failure.message : 'Operazione non riuscita.'},400);
  }
});
